
<?php $__env->startSection('admindash'); ?>

    Hi Welcome to admin Dashboard
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\3rd year\laravel practice\Assignments\Assignment1\E-storeManagementSystem\resources\views/admin/admindashboard.blade.php ENDPATH**/ ?>