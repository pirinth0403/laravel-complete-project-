
<?php $__env->startSection('customerdash'); ?>
   <!-- error messages --> 
<div class="container">
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


</div>
<form action="<?php echo e(route('orders.store')); ?>" method="post">
  <?php echo csrf_field(); ?>
  <?php echo e($products->pname); ?>

  <br/>
  <br/>
  <label for="price">employeeName</label>
  <select name="employee_id">
      <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
  </select>

  <br/>
  <br/>
  <?php echo e($products->price); ?>

  <br/>
  
  <input type="text" name="products_id" value="<?php echo e($products->id); ?>" class="form-control" placeholder="Detail">
  <input type="hidden"  name="customer_id" value="<?php echo e(Auth::user()->id); ?>">
  <br/>
  <br/>
  
  <button type="submit" class="btn btn-primary">Add</button>
</form>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('customers.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\3rd year\laravel practice\Assignments\Assignment1\E-storeManagementSystem\resources\views/orders/create.blade.php ENDPATH**/ ?>