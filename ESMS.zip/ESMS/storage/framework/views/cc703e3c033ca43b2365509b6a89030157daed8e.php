
<?php $__env->startSection('customerdash'); ?>

    <div class="container">
    
   
   <!-- success alert message -->
   <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    
 
   
    
        
   
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Details</th>
            <th>price</th>
            <th width="280px">Actions </th>
        </tr>
        <?php
            $id = 0;
            ?>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <tr>
           
            <td><?php echo e(++$id); ?></td>
            <td><?php echo e($product->pname); ?></td>
            <td><?php echo e($product->detail); ?></td>
            <td><?php echo e($product->price); ?></td>
            <td>
                <a href="<?php echo e(route('placeorder',['products'=>$product->id])); ?>"><button class="btn btn-primary"> PlaceOrder</button></a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customers.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\3rd year\laravel practice\Assignments\Assignment1\E-storeManagementSystem\resources\views/orders/index.blade.php ENDPATH**/ ?>