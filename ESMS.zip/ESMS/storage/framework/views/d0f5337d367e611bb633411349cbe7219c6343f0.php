
<?php $__env->startSection('admindash'); ?>

<div class="row">
        
    </div>
   
    <div class="container">
        <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Employee Details</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('employees.index')); ?>"> Back</a>
            </div>
          
<table>
    <thead>
      <tr>
        <th>Name:</th>
        <th><?php echo e($user->name); ?></th>   
      </tr>
      <tr>
        <th>E-mail:</th>
        <th><?php echo e($user->email); ?></th>   
      </tr>
      <tr>
        <th>Gender:</th>
        <th><?php echo e($user->gender); ?></th>   
      </tr>

      <tr>
        <th>Address:</th>
        <th><?php echo e($user->address); ?></th>   
      </tr>
    </thead>
    <tr>
        <th>MobileNo:</th>
        <th><?php echo e($user->mobileno); ?></th>   
      </tr>
    
  </table>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\3rd year\laravel practice\Assignments\Assignment1\E-storeManagementSystem\resources\views/employee/show.blade.php ENDPATH**/ ?>