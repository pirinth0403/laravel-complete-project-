
<?php $__env->startSection('admindash'); ?>

<div>
    <div class="row">
      <div class="col lg-7"><h1>Add a New Product</h1></div>
    
      <div class="col lg-5">
      <a class="btn btn-primary" href="<?php echo e(route('products.index')); ?>"> Back</a>
    </div>
        
 </div>

 <!-- error messages --> 

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


</div>
<form action="<?php echo e(route('products.store')); ?>" method="post">
  <?php echo csrf_field(); ?>
    <div class="form-group">
    <label for="name">Name:</label>
    <input type="text" class="form-control" placeholder="Enter product name" id="name" name="pname">
    </div>
  
  
  <div class="form-group">
    <label for="Detail">Detail:</label>
    <input type="text" class="form-control" placeholder="Enter detail" id="detail" name="detail">
    </div>
    <div class="form-group">
    <label for="price">Price:</label>
    <input type="number" class="form-control" placeholder="Enter price" id="price" name="price">
    </div>
  
  
  <button type="submit" class="btn btn-primary">Add</button>
</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\3rd year\laravel practice\Assignments\Assignment1\E-storeManagementSystem\resources\views/product/create.blade.php ENDPATH**/ ?>