
<?php $__env->startSection('customerdash'); ?>

    <div class="container">
        <h2>
            Hi Welcome to Customers Dashboard
        </h2>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customers.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\3rd year\laravel practice\Assignments\Assignment1\E-storeManagementSystem\resources\views/customers/dash.blade.php ENDPATH**/ ?>