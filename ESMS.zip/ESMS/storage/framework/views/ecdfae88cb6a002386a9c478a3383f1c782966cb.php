
<?php $__env->startSection('admindash'); ?>

<table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>email</th>
            <th>gender</th>
            <th>address</th>
            <th>mobile</th>
            <th>role</th>
            
            
        </tr>
        <?php
            $id = 0;
            ?>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <tr>
           
            <td><?php echo e(++$id); ?></td>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->gender); ?></td>
            <td><?php echo e($user->address); ?></td>
            <td><?php echo e($user->mobileno); ?></td>
            <td><?php echo e($user->role); ?></td>
            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\3rd year\laravel practice\Assignments\Assignment1\E-storeManagementSystem\resources\views/show.blade.php ENDPATH**/ ?>