@extends('admin.base')
@section('admindash')

    Hi Welcome to admin Dashboard
@endsection