@extends('customers.base')
@section('customerdash')

    <div class="container">
        <h2>
            Hi Welcome to Customers Dashboard
        </h2>
    </div>
@endsection